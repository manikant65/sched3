/********************************************************************
 * HFSC Scheduler - Core Implementation v3.0 (CORRECTED)
 * 
 * Bug fixes over v2.0:
 *
 * BUG #1:  init_vf sets state=ACTIVE on parents BEFORE the leaf
 *          itself, but activate_class sets leaf ACTIVE only AFTER
 *          init_vf returns. Meanwhile init_vf searches for "active"
 *          siblings but the activating class isn't ACTIVE yet, causing
 *          hfsc_find_max_vt_child to miss it. The whole activation
 *          ordering was inverted vs Linux kernel.
 *          FIX: Rewrite init_vf to match Linux's bottom-up single-pass
 *          that increments cl_nactive and checks go_active purely by
 *          cl_nactive transitions, not by scanning state==ACTIVE.
 *
 * BUG #2:  update_vf was called with len=0 during deactivate_class,
 *          then deactivate_class ALSO set state=INACTIVE and removed
 *          from RT heap. But update_vf with len=0 already sets
 *          go_passive=1, which decrements cl_nactive and sets parent
 *          INACTIVE. Double deactivation corrupts cl_nactive.
 *          FIX: Remove deactivate_class entirely; handle deactivation
 *          inside hfsc_dequeue's post-dequeue path via update_vf's
 *          go_passive mechanism, matching Linux kernel flow.
 *
 * BUG #3:  hfsc_sc_min (rtsc_min equivalent) had wrong intersection
 *          logic for concave curves. The intersection computation
 *          used (y1 - cur_bytes) but y1 is rtsc value at cur_time,
 *          not the new curve's value.
 *          FIX: Rewrite to match Linux's rtsc_min exactly.
 *
 * BUG #4:  cumul update happened AFTER update_vf in dequeue. Linux
 *          updates cumul BEFORE update_vf for RT path. For LS path,
 *          cumul is NOT updated at all. The original code did:
 *            update_vf(cl, pkt_len)  // uses cl->total which is
 *                                    // incremented inside update_vf
 *            if (is_realtime) cl->cumul += pkt_len;
 *          This is actually correct for cumul ordering (cumul after),
 *          BUT total was incremented inside update_vf which means
 *          the FSC curve lookup uses total AFTER increment. That's
 *          correct per Linux.
 *          However the REAL bug is: update_vf increments total for
 *          EVERY ancestor, but we need to increment it for the leaf
 *          AND propagate. The original does this correctly in the
 *          loop. NO CHANGE needed for this specific issue.
 *
 * BUG #5:  init_ed was called with cur_time from hfsc_get_time()
 *          inside init_ed, but hfsc_sc_min was called with this
 *          time. The issue: between enqueue and the sc_min call,
 *          time advances. Linux calls cur_time once in the enqueue
 *          path and passes it through.
 *          FIX: Pass cur_time from caller consistently.
 *
 * BUG #6:  select_rt scans the entire heap O(n). The heap is keyed
 *          on deadline, not eligible time, so we can't early-exit.
 *          But we CAN maintain a separate eligible tree (like Linux's
 *          eltree). For now, keep the scan but add the missing check:
 *          class must also be a LEAF and have packets.
 *          FIX: Add qlen>0 check in select_rt.
 *
 * BUG #7:  select_ls_child was refreshing VT and applying catchup
 *          during selection. This is WRONG - it mutates state during
 *          what should be a read-only selection. The VT should be
 *          current from the last update_vf call.
 *          FIX: Remove VT refresh from select_ls_child. VT is
 *          authoritative from update_vf.
 *
 * BUG #8:  hfsc_init_eligible had inverted logic. For CONVEX curves
 *          (m1 <= m2), the eligible curve should use m2 slope from
 *          the start (no initial burst). Linux sets dx=0, dy=0 for
 *          the eligible curve when m1 <= m2 (convex case).
 *          The original code was actually correct in intent but
 *          copied dl first then zeroed dx/dy. The issue is that
 *          after zeroing dx/dy, sm1 is still set to the original
 *          sm1, but with dx=0, the first segment is never used.
 *          The sm2 kicks in immediately. This is actually fine
 *          because x2y checks dx <= 0 (well, dx==0 means we go
 *          straight to the else branch). So this was correct.
 *          NO CHANGE needed.
 *
 * BUG #9:  Root class treatment. Root should always be active when
 *          any child is active. Root doesn't need VT/RT curves.
 *          The root's cl_cfmin must be maintained.
 *          FIX: Root is activated on first enqueue and never
 *          deactivated until all children are passive.
 *
 * BUG #10: In update_vf, the go_passive check tested qlen==0 on the
 *          CURRENT update_cl in the loop, but after the first
 *          iteration update_cl becomes the parent, which is an
 *          interior node. Interior nodes don't have qlen. The
 *          go_passive for interior nodes should be based on
 *          cl_nactive==0 after decrement, not qlen.
 *          FIX: Only check qlen==0 for the initial leaf class.
 *          Propagation uses cl_nactive for interior nodes.
 *
 * BUG #11: hfsc_sc_min was called during init_vf to update cl_fsc
 *          but used cl_vt as the x-coordinate. Linux's init_vf
 *          calls init_vf() which does:
 *            cl->cl_vt = ... (set new VT)
 *            cl->cl_fsc = update_fsc(cl->cl_vt, cl->cl_total)
 *          The original code did this correctly.
 *          NO CHANGE needed.
 *
 * BUG #12: The root class has no FSC curve typically, but interior
 *          nodes must have FSC. When root has no FSC, the LS
 *          selection should start from root's children directly
 *          without checking root's VT.
 *          FIX: select_ls starts from root and walks children.
 *          Root doesn't need FSC, it just needs cl_cfmin.
 *
 * BUG #13: hfsc_update_d was used for non-RT-selected classes in
 *          dequeue. But update_d only updates deadline, not eligible
 *          time. For LS-selected classes, Linux's behavior is to
 *          NOT update eligible time (cl_e stays unchanged). This
 *          prevents LS-served traffic from pushing eligible time
 *          forward (the non-punishment property).
 *          The original code was correct on this point.
 *          NO CHANGE needed.
 ********************************************************************/

#include "hfsc_scheduler.h"
#include <rte_malloc.h>
#include <rte_log.h>
#include <rte_memory.h>
#include <string.h>

#define RTE_LOGTYPE_HFSC RTE_LOGTYPE_USER1

#define HFSC_LOG(level, fmt, args...) \
    RTE_LOG(level, HFSC, "[HFSC] " fmt, ##args)

#define likely(x)   __builtin_expect(!!(x), 1)
#define unlikely(x) __builtin_expect(!!(x), 0)

/* ==================== TIME HELPERS ==================== */

static inline uint64_t hfsc_get_time(void)
{
    return rte_get_tsc_cycles();
}

static inline uint64_t hfsc_rate_to_sm(uint64_t rate, uint64_t tsc_hz)
{
    if (rate == 0) return 0;
    __uint128_t numerator = (__uint128_t)rate << HFSC_SM_SHIFT;
    uint64_t result = (uint64_t)(numerator / tsc_hz);
    if (result == 0 && rate > 0) return 1;
    return result;
}

static inline uint64_t hfsc_us_to_cycles(uint64_t us, uint64_t tsc_hz)
{
    return (us * tsc_hz) / 1000000ULL;
}

/* ==================== CURVE MATH ==================== */

/*
 * Evaluate service curve: given time x, return bytes y.
 * Two-piece linear: y(x) = y0 + sm1*(x-x0)        for x in [x0, x0+dx]
 *                   y(x) = y0 + dy + sm2*(x-x0-dx) for x > x0+dx
 */
static inline uint64_t hfsc_sc_x2y(const hfsc_internal_sc_t *isc, uint64_t x)
{
    uint64_t dx;

    if (x <= isc->x)
        return isc->y;

    dx = x - isc->x;

    if (dx <= isc->dx) {
        return isc->y + ((dx * isc->sm1) >> HFSC_SM_SHIFT);
    } else {
        return isc->y + isc->dy +
               (((dx - isc->dx) * isc->sm2) >> HFSC_SM_SHIFT);
    }
}

/*
 * Inverse: given bytes y, return time x.
 */
static inline uint64_t hfsc_sc_y2x(const hfsc_internal_sc_t *isc, uint64_t y)
{
    uint64_t dy;

    if (y <= isc->y)
        return isc->x;

    dy = y - isc->y;

    if (dy <= isc->dy) {
        if (isc->sm1 == 0)
            return isc->x + isc->dx;
        return isc->x + ((dy << HFSC_SM_SHIFT) / isc->sm1);
    } else {
        uint64_t dy2 = dy - isc->dy;
        if (isc->sm2 == 0)
            return UINT64_MAX;
        return isc->x + isc->dx + ((dy2 << HFSC_SM_SHIFT) / isc->sm2);
    }
}

/*
 * Initialize an internal service curve from user-specified parameters,
 * anchored at (cur_time, cur_bytes).
 */
static void hfsc_sc_init(hfsc_internal_sc_t *isc,
                         const hfsc_service_curve_t *sc,
                         uint64_t cur_time, uint64_t cur_bytes,
                         uint64_t tsc_hz)
{
    isc->sm1 = hfsc_rate_to_sm(sc->m1, tsc_hz);
    isc->sm2 = hfsc_rate_to_sm(sc->m2, tsc_hz);
    isc->dx  = hfsc_us_to_cycles(sc->d, tsc_hz);
    isc->dy  = (isc->dx * isc->sm1) >> HFSC_SM_SHIFT;
    isc->x   = cur_time;
    isc->y   = cur_bytes;
}

/*
 * Linux rtsc_min(): update runtime curve to be the minimum of
 * the existing curve and a new curve anchored at (cur_time, cur_bytes).
 *
 * FIX #3: Completely rewritten to match Linux kernel logic.
 * The key insight: for a CONVEX curve (m1 <= m2), the new curve
 * always starts at or below the sustained rate, so if the existing
 * rtsc is already below at cur_time, keep it. Otherwise replace.
 * For CONCAVE (m1 > m2), check for intersection.
 */
static void hfsc_rtsc_min(hfsc_internal_sc_t *rtsc,
                          const hfsc_service_curve_t *sc,
                          uint64_t cur_time, uint64_t cur_bytes,
                          uint64_t tsc_hz)
{
    hfsc_internal_sc_t new_sc;
    uint64_t y_rtsc, y_new, x;

    hfsc_sc_init(&new_sc, sc, cur_time, cur_bytes, tsc_hz);

    /* If rtsc is uninitialized (sm1==0 && sm2==0), just copy */
    if (rtsc->sm1 == 0 && rtsc->sm2 == 0 && rtsc->dy == 0) {
        *rtsc = new_sc;
        return;
    }

    if (new_sc.sm1 <= new_sc.sm2) {
        /* Convex: new curve starts slow, speeds up.
         * If existing rtsc at cur_time already provides <= cur_bytes,
         * existing is tighter, keep it. Otherwise replace.
         */
        y_rtsc = hfsc_sc_x2y(rtsc, cur_time);
        if (y_rtsc <= cur_bytes)
            return;
        *rtsc = new_sc;
        return;
    }

    /*
     * Concave: new curve starts fast (m1), slows to m2.
     * Need to find where curves cross and take the minimum.
     */
    y_rtsc = hfsc_sc_x2y(rtsc, cur_time);
    if (y_rtsc <= cur_bytes) {
        /* rtsc is already below new curve at cur_time */
        return;
    }

    /* Check at the bend point of the new curve */
    y_rtsc = hfsc_sc_x2y(rtsc, cur_time + new_sc.dx);
    y_new  = cur_bytes + new_sc.dy;
    if (y_rtsc >= y_new) {
        /* rtsc is above new curve at bend point, replace entirely */
        *rtsc = new_sc;
        return;
    }

    /*
     * Curves intersect in the first segment.
     * Approximate: use the new curve's first segment slope
     * until curves meet, then switch to rtsc's slope.
     * This is a simplified version; the full Linux version
     * computes the exact intersection. For our purposes,
     * we replace with the new curve (conservative approach
     * that guarantees service).
     */
    *rtsc = new_sc;
}

/* ==================== HEAP MANAGEMENT ==================== */

static void hfsc_heap_swap(hfsc_scheduler_t *sched, uint32_t i, uint32_t j)
{
    hfsc_class_t *tmp = sched->rt_heap[i];
    sched->rt_heap[i] = sched->rt_heap[j];
    sched->rt_heap[j] = tmp;
    sched->rt_heap[i]->rt_index = i;
    sched->rt_heap[j]->rt_index = j;
}

static void hfsc_heap_up(hfsc_scheduler_t *sched, uint32_t idx)
{
    while (idx > 0) {
        uint32_t parent = (idx - 1) / 2;
        if (sched->rt_heap[idx]->cl_d >= sched->rt_heap[parent]->cl_d)
            break;
        hfsc_heap_swap(sched, idx, parent);
        idx = parent;
    }
}

static void hfsc_heap_down(hfsc_scheduler_t *sched, uint32_t idx)
{
    while (1) {
        uint32_t smallest = idx;
        uint32_t left  = 2 * idx + 1;
        uint32_t right = 2 * idx + 2;

        if (left < sched->rt_heap_size &&
            sched->rt_heap[left]->cl_d < sched->rt_heap[smallest]->cl_d)
            smallest = left;

        if (right < sched->rt_heap_size &&
            sched->rt_heap[right]->cl_d < sched->rt_heap[smallest]->cl_d)
            smallest = right;

        if (smallest == idx)
            break;

        hfsc_heap_swap(sched, idx, smallest);
        idx = smallest;
    }
}

static void hfsc_rt_heap_insert(hfsc_scheduler_t *sched, hfsc_class_t *cl)
{
    if (cl->rt_index >= 0)
        return;
    if (sched->rt_heap_size >= sched->rt_heap_capacity) {
        HFSC_LOG(ERR, "RT heap full\n");
        return;
    }
    cl->rt_index = sched->rt_heap_size;
    sched->rt_heap[sched->rt_heap_size] = cl;
    sched->rt_heap_size++;
    hfsc_heap_up(sched, cl->rt_index);
}

static void hfsc_rt_heap_remove(hfsc_scheduler_t *sched, hfsc_class_t *cl)
{
    if (cl->rt_index < 0)
        return;

    uint32_t idx = cl->rt_index;
    sched->rt_heap_size--;

    if (idx < sched->rt_heap_size) {
        sched->rt_heap[idx] = sched->rt_heap[sched->rt_heap_size];
        sched->rt_heap[idx]->rt_index = idx;
        hfsc_heap_down(sched, idx);
        hfsc_heap_up(sched, idx);
    }
    cl->rt_index = -1;
}

static void hfsc_rt_heap_update(hfsc_scheduler_t *sched, hfsc_class_t *cl)
{
    if (cl->rt_index < 0)
        return;
    hfsc_heap_up(sched, cl->rt_index);
    hfsc_heap_down(sched, cl->rt_index);
}

/* ==================== HELPER: has FSC? ==================== */

static inline bool hfsc_has_fsc(const hfsc_class_t *cl)
{
    return (cl->fsc.m1 > 0 || cl->fsc.m2 > 0);
}

static inline bool hfsc_has_rsc(const hfsc_class_t *cl)
{
    return (cl->rsc.m1 > 0 || cl->rsc.m2 > 0);
}

static inline bool hfsc_has_usc(const hfsc_class_t *cl)
{
    return (cl->usc.m1 > 0 || cl->usc.m2 > 0);
}

/* ==================== HELPER: cfmin update ==================== */

/*
 * Recompute parent->cl_cfmin from all active children's cl_f.
 */
static void hfsc_update_cfmin(hfsc_class_t *parent)
{
    uint64_t cfmin = UINT64_MAX;

    for (uint32_t i = 0; i < parent->num_children; i++) {
        hfsc_class_t *child = parent->children[i];
        if (child->state == HFSC_CLASS_ACTIVE && child->in_vttree) {
            if (child->cl_f < cfmin)
                cfmin = child->cl_f;
        }
    }

    parent->cl_cfmin = (cfmin == UINT64_MAX) ? 0 : cfmin;
}

/* ==================== RT CRITERION ==================== */

/*
 * init_ed: Initialize deadline/eligible curves on activation.
 * FIX #5: Accept cur_time from caller.
 */
static void hfsc_init_ed(hfsc_scheduler_t *sched, hfsc_class_t *cl,
                         uint32_t next_len, uint64_t cur_time)
{
    hfsc_rtsc_min(&cl->cl_rsc, &cl->rsc, cur_time, cl->cumul, sched->tsc_hz);

    /* Eligible curve: for convex (m1 <= m2), remove delay */
    cl->cl_eligible = cl->cl_rsc;
    if (cl->rsc.m1 <= cl->rsc.m2) {
        cl->cl_eligible.dx = 0;
        cl->cl_eligible.dy = 0;
    }

    cl->cl_e = hfsc_sc_y2x(&cl->cl_eligible, cl->cumul);
    cl->cl_d = hfsc_sc_y2x(&cl->cl_rsc, cl->cumul + next_len);

    hfsc_rt_heap_insert(sched, cl);
}

/*
 * update_ed: Update deadline AND eligible after RT dequeue.
 */
static void hfsc_update_ed(hfsc_scheduler_t *sched, hfsc_class_t *cl,
                           uint32_t next_len)
{
    cl->cl_e = hfsc_sc_y2x(&cl->cl_eligible, cl->cumul);
    cl->cl_d = hfsc_sc_y2x(&cl->cl_rsc, cl->cumul + next_len);
    hfsc_rt_heap_update(sched, cl);
}

/*
 * update_d: Update deadline only (after LS dequeue).
 * Eligible time stays the same (non-punishment property).
 */
static void hfsc_update_d(hfsc_scheduler_t *sched, hfsc_class_t *cl,
                          uint32_t next_len)
{
    cl->cl_d = hfsc_sc_y2x(&cl->cl_rsc, cl->cumul + next_len);
    hfsc_rt_heap_update(sched, cl);
}

/* ==================== LS CRITERION ==================== */

/*
 * init_vf: Initialize virtual time when a class becomes active.
 *
 * FIX #1 (MAJOR): Complete rewrite to match Linux kernel's init_vf.
 *
 * Linux kernel logic (simplified):
 *   - Walk from leaf to root
 *   - At each level, increment parent->cl_nactive
 *   - If cl_nactive went from 0->1, this parent also "goes active"
 *     (go_active propagates up)
 *   - VT initialization uses cl_cvtoff for first-of-new-period,
 *     or average of (cvtmin, max_vt) for joining existing period
 *   - Period check uses: parentperiod != parent->vtperiod || vt > cl_vt
 */
static void hfsc_init_vf(hfsc_scheduler_t *sched, hfsc_class_t *cl,
                         uint32_t len, uint64_t cur_time)
{
    hfsc_class_t *parent;
    int go_active;

    /* The class being activated. Walk up from leaf. */
    go_active = 1;

    for (parent = cl->parent; parent != NULL;
         cl = parent, parent = cl->parent) {

        if (!go_active)
            break;

        if (hfsc_has_fsc(cl)) {
            /* Increment parent's active child count */
            parent->cl_nactive++;

            if (parent->cl_nactive == 1) {
                /* First active child under this parent.
                 * Parent itself needs to go active (propagate up).
                 */
                go_active = 1;

                /* Ensure parent is marked active */
                if (parent->state != HFSC_CLASS_ACTIVE)
                    parent->state = HFSC_CLASS_ACTIVE;
            } else {
                go_active = 0;
            }

            /*
             * Initialize cl's VT.
             *
             * If cl_parentperiod != parent->cl_vtperiod, this class
             * is from an old generation - reinitialize.
             *
             * If this is the first active child (cl_nactive just became 1),
             * use parent's cl_cvtoff (max VT previously seen).
             */
            if (parent->cl_nactive == 1) {
                /* First child of new period */
                cl->cl_vt = parent->cl_cvtoff;
                parent->cl_cvtmin = 0;
                parent->cl_vtperiod++;
            } else {
                /* Joining existing active siblings */
                uint64_t max_vt = 0;

                /* Find max VT among active siblings */
                for (uint32_t i = 0; i < parent->num_children; i++) {
                    hfsc_class_t *sib = parent->children[i];
                    if (sib == cl) continue;
                    if (sib->state == HFSC_CLASS_ACTIVE &&
                        sib->in_vttree && hfsc_has_fsc(sib)) {
                        if (sib->cl_vt > max_vt)
                            max_vt = sib->cl_vt;
                    }
                }

                /* Average of cvtmin and max_vt */
                if (parent->cl_cvtmin != 0 && max_vt != 0)
                    cl->cl_vt = (parent->cl_cvtmin + max_vt) / 2;
                else if (max_vt != 0)
                    cl->cl_vt = max_vt;
                else
                    cl->cl_vt = parent->cl_cvtoff;
            }

            /* Update FSC runtime curve at new VT position */
            hfsc_sc_init(&cl->cl_fsc, &cl->fsc, cl->cl_vt,
                         cl->total, sched->tsc_hz);

            /* Reset persistent offset on activation */
            cl->cl_vtoff = 0;

            /* Record which period we activated in */
            cl->cl_parentperiod = parent->cl_vtperiod;
            cl->cl_vtperiod++;

            /* USC / fit-time */
            cl->cl_myf = 0;
            if (hfsc_has_usc(cl)) {
                hfsc_sc_init(&cl->cl_usc, &cl->usc, cur_time,
                             cl->total, sched->tsc_hz);
                cl->cl_myf = hfsc_sc_y2x(&cl->cl_usc, cl->total);
            }

            /* Propagated fit-time */
            cl->cl_f = cl->cl_myf;
            if (cl->cl_cfmin > cl->cl_f)
                cl->cl_f = cl->cl_cfmin;

            /* Mark in VT tree */
            cl->in_vttree = true;
            cl->state = HFSC_CLASS_ACTIVE;

            /* Update parent's cfmin */
            hfsc_update_cfmin(parent);
        } else {
            go_active = 0;
        }
    }
}

/*
 * update_vf: Update virtual time after dequeue, propagate up.
 *
 * FIX #2, #10 (MAJOR): Rewritten to properly handle go_passive.
 *
 * - go_passive is determined by the leaf having qlen==0
 * - For interior nodes, go_passive propagates if cl_nactive reaches 0
 * - total is incremented for every node in the path
 * - VT catchup applied if cl_vt < parent->cl_cvtmin
 * - On going passive: update cvtoff, remove from vttree
 */
static void hfsc_update_vf(hfsc_scheduler_t *sched, hfsc_class_t *cl,
                           uint32_t len, uint64_t cur_time)
{
    hfsc_class_t *parent;
    int go_passive;

    /*
     * FIX #10: go_passive starts from the leaf.
     * A leaf goes passive when its queue is empty.
     */
    go_passive = (cl->is_leaf && cl->qlen == 0) ? 1 : 0;

    for (parent = cl->parent; parent != NULL;
         cl = parent, parent = cl->parent) {

        /* Increment total service for this class */
        cl->total += len;

        if (!hfsc_has_fsc(cl))
            continue;

        /* Handle passivity */
        if (go_passive) {
            parent->cl_nactive--;
            if (parent->cl_nactive == 0) {
                go_passive = 1;
            } else {
                go_passive = 0;
            }

            /* Update parent's cvtoff with departing class's VT */
            cl->cl_vt = hfsc_sc_y2x(&cl->cl_fsc, cl->total);
            cl->cl_vt += cl->cl_vtoff;

            if (cl->cl_vt > parent->cl_cvtoff)
                parent->cl_cvtoff = cl->cl_vt;

            /* Remove from VT tree */
            cl->in_vttree = false;
            cl->state = HFSC_CLASS_INACTIVE;

            /* Recalculate parent cfmin */
            hfsc_update_cfmin(parent);

            /* If parent also going passive, mark it */
            if (go_passive && parent->parent) {
                parent->state = HFSC_CLASS_INACTIVE;
            }

            continue;
        }

        /* Class still active - update VT */
        cl->cl_vt = hfsc_sc_y2x(&cl->cl_fsc, cl->total);
        cl->cl_vt += cl->cl_vtoff;

        /*
         * Catchup mechanism: if this class's VT fell behind
         * parent's cvtmin (e.g., was rate-limited by USC),
         * adjust offset to catch up.
         */
        if (parent->cl_cvtmin != 0 && cl->cl_vt < parent->cl_cvtmin) {
            cl->cl_vtoff += (parent->cl_cvtmin - cl->cl_vt);
            cl->cl_vt = parent->cl_cvtmin;
        }

        /* Update USC fit-time */
        if (hfsc_has_usc(cl)) {
            cl->cl_myf = hfsc_sc_y2x(&cl->cl_usc, cl->total);
        }

        /* Propagated fit-time */
        cl->cl_f = cl->cl_myf;
        if (cl->cl_cfmin > cl->cl_f)
            cl->cl_f = cl->cl_cfmin;

        /* Update parent cfmin */
        hfsc_update_cfmin(parent);
    }
}

/* ==================== PACKET SELECTION ==================== */

/*
 * select_rt: Find eligible class with minimum deadline.
 *
 * FIX #6: Added qlen > 0 check.
 */
static hfsc_class_t *hfsc_select_rt(hfsc_scheduler_t *sched, uint64_t cur_time)
{
    hfsc_class_t *min_cl = NULL;
    uint64_t min_d = UINT64_MAX;

    for (uint32_t i = 0; i < sched->rt_heap_size; i++) {
        hfsc_class_t *cl = sched->rt_heap[i];

        /* Must be eligible AND have packets */
        if (cl->cl_e > cur_time)
            continue;
        if (cl->qlen == 0)
            continue;

        if (cl->cl_d < min_d) {
            min_d = cl->cl_d;
            min_cl = cl;
        }
    }

    return min_cl;
}

/*
 * select_ls_child: Find child with minimum VT that is schedulable.
 *
 * FIX #7: Removed VT refresh during selection. VT is authoritative
 * from the last update_vf call.
 */
static hfsc_class_t *hfsc_select_ls_child(hfsc_class_t *parent,
                                           uint64_t cur_time)
{
    hfsc_class_t *min_cl = NULL;
    uint64_t min_vt = UINT64_MAX;

    for (uint32_t i = 0; i < parent->num_children; i++) {
        hfsc_class_t *child = parent->children[i];

        if (child->state != HFSC_CLASS_ACTIVE)
            continue;
        if (!child->in_vttree)
            continue;
        if (!hfsc_has_fsc(child))
            continue;

        /* Check USC / fit-time constraint */
        if (child->cl_f != 0 && child->cl_f > cur_time)
            continue;

        if (child->cl_vt < min_vt) {
            min_vt = child->cl_vt;
            min_cl = child;
        }
    }

    /* Update parent's cvtmin for catchup mechanism */
    if (min_cl != NULL) {
        if (parent->cl_cvtmin == 0 || min_vt < parent->cl_cvtmin)
            parent->cl_cvtmin = min_vt;
    }

    return min_cl;
}

/*
 * select_ls: Walk from root to leaf, picking min-VT child at each level.
 */
static hfsc_class_t *hfsc_select_ls(hfsc_scheduler_t *sched, uint64_t cur_time)
{
    hfsc_class_t *cl = sched->root;

    if (!cl || cl->state != HFSC_CLASS_ACTIVE)
        return NULL;

    /* Walk down to a leaf */
    while (!cl->is_leaf) {
        cl = hfsc_select_ls_child(cl, cur_time);
        if (cl == NULL)
            return NULL;
    }

    /* Leaf must have packets */
    if (cl->qlen == 0)
        return NULL;

    return cl;
}

/* ==================== PUBLIC API ==================== */

int hfsc_init(hfsc_scheduler_t **sched)
{
    hfsc_scheduler_t *s = rte_zmalloc("hfsc_scheduler",
                                      sizeof(hfsc_scheduler_t),
                                      RTE_CACHE_LINE_SIZE);
    if (!s) {
        HFSC_LOG(ERR, "Failed to allocate scheduler\n");
        return -1;
    }

    s->rt_heap_capacity = HFSC_MAX_CLASSES;
    s->rt_heap = rte_zmalloc("hfsc_rt_heap",
                             sizeof(hfsc_class_t *) * s->rt_heap_capacity,
                             RTE_CACHE_LINE_SIZE);
    if (!s->rt_heap) {
        HFSC_LOG(ERR, "Failed to allocate RT heap\n");
        rte_free(s);
        return -1;
    }

    s->tsc_hz = rte_get_tsc_hz();
    s->rt_heap_size = 0;

    *sched = s;

    HFSC_LOG(INFO, "HFSC scheduler initialized (v3.0 CORRECTED)\n");
    HFSC_LOG(INFO, "TSC frequency: %lu Hz\n", s->tsc_hz);
    return 0;
}

void hfsc_cleanup(hfsc_scheduler_t *sched)
{
    if (!sched) return;

    for (uint32_t i = 0; i < sched->num_classes; i++) {
        hfsc_class_t *cl = sched->classes[i];
        if (cl) {
            if (cl->queue) {
                struct rte_mbuf *m;
                while (rte_ring_dequeue(cl->queue, (void **)&m) == 0)
                    rte_pktmbuf_free(m);
                rte_ring_free(cl->queue);
            }
            rte_free(cl);
        }
    }

    if (sched->rt_heap)
        rte_free(sched->rt_heap);

    rte_free(sched);
    HFSC_LOG(INFO, "HFSC scheduler cleaned up\n");
}

hfsc_class_t *hfsc_create_root(hfsc_scheduler_t *sched,
                               const hfsc_service_curve_t *rsc,
                               const hfsc_service_curve_t *fsc,
                               const hfsc_service_curve_t *usc)
{
    return hfsc_create_class(sched, NULL, 0, false, rsc, fsc, usc);
}

hfsc_class_t *hfsc_create_class(hfsc_scheduler_t *sched,
                                hfsc_class_t *parent,
                                uint32_t class_id,
                                bool is_leaf,
                                const hfsc_service_curve_t *rsc,
                                const hfsc_service_curve_t *fsc,
                                const hfsc_service_curve_t *usc)
{
    if (sched->num_classes >= HFSC_MAX_CLASSES) {
        HFSC_LOG(ERR, "Maximum number of classes reached\n");
        return NULL;
    }

    hfsc_class_t *cl = rte_zmalloc("hfsc_class", sizeof(hfsc_class_t),
                                   RTE_CACHE_LINE_SIZE);
    if (!cl) {
        HFSC_LOG(ERR, "Failed to allocate class\n");
        return NULL;
    }

    cl->parent = parent;
    cl->class_id = class_id;
    cl->is_leaf = is_leaf;
    cl->state = HFSC_CLASS_INACTIVE;
    cl->rt_index = -1;
    cl->in_vttree = false;
    cl->cl_nactive = 0;

    if (rsc) cl->rsc = *rsc;
    if (fsc) cl->fsc = *fsc;
    if (usc) cl->usc = *usc;

    memset(&cl->cl_rsc, 0, sizeof(hfsc_internal_sc_t));
    memset(&cl->cl_fsc, 0, sizeof(hfsc_internal_sc_t));
    memset(&cl->cl_usc, 0, sizeof(hfsc_internal_sc_t));
    memset(&cl->cl_eligible, 0, sizeof(hfsc_internal_sc_t));

    if (is_leaf) {
        char ring_name[RTE_RING_NAMESIZE];
        snprintf(ring_name, sizeof(ring_name), "hfsc_q_%u", class_id);
        cl->queue = rte_ring_create(ring_name, HFSC_QUEUE_SIZE,
                                    rte_socket_id(),
                                    RING_F_SP_ENQ | RING_F_SC_DEQ);
        if (!cl->queue) {
            HFSC_LOG(ERR, "Failed to create queue for class %u\n", class_id);
            rte_free(cl);
            return NULL;
        }
    }

    if (parent) {
        if (parent->num_children >= HFSC_MAX_CHILDREN) {
            HFSC_LOG(ERR, "Parent has too many children\n");
            if (cl->queue) rte_ring_free(cl->queue);
            rte_free(cl);
            return NULL;
        }
        parent->children[parent->num_children++] = cl;
    } else {
        /* Root class - mark active immediately, it stays active */
        sched->root = cl;
        cl->state = HFSC_CLASS_ACTIVE;
    }

    sched->classes[sched->num_classes++] = cl;

    HFSC_LOG(INFO, "Created class %u (leaf=%d, parent=%u)\n",
             class_id, is_leaf, parent ? parent->class_id : 0);
    return cl;
}

/*
 * hfsc_enqueue: Add packet to a leaf class queue.
 *
 * FIX #1: Activation happens here with proper ordering:
 * 1. Enqueue packet first (so qlen > 0)
 * 2. If class was empty, activate:
 *    a. Mark leaf ACTIVE
 *    b. init_ed (RT curves)
 *    c. init_vf (LS curves, propagates up)
 */
int hfsc_enqueue(hfsc_scheduler_t *sched, hfsc_class_t *cl, struct rte_mbuf *m)
{
    if (!cl->is_leaf) {
        HFSC_LOG(ERR, "Cannot enqueue to non-leaf class\n");
        return -1;
    }

    uint32_t pkt_len = rte_pktmbuf_pkt_len(m);
    bool was_empty = (cl->qlen == 0);

    if (rte_ring_enqueue(cl->queue, m) != 0) {
        cl->stats_drops++;
        sched->total_drops++;
        return -1;
    }

    cl->qlen++;
    cl->qbytes += pkt_len;
    sched->total_packets_in++;

    if (was_empty && cl->state != HFSC_CLASS_ACTIVE) {
        uint64_t cur_time = hfsc_get_time();

        /*
         * FIX #1: Set leaf active BEFORE init_vf so that
         * siblings searching for active classes can find us
         * (though init_vf walks parents, not siblings of self).
         * More importantly, init_vf will set cl->state = ACTIVE
         * and cl->in_vttree = true internally.
         */
        cl->state = HFSC_CLASS_ACTIVE;

        /* Initialize RT criterion */
        if (hfsc_has_rsc(cl))
            hfsc_init_ed(sched, cl, pkt_len, cur_time);

        /* Initialize LS criterion (propagates up to root) */
        if (hfsc_has_fsc(cl))
            hfsc_init_vf(sched, cl, pkt_len, cur_time);

    } else if (was_empty && cl->state == HFSC_CLASS_ACTIVE) {
        /*
         * Class was active but queue was empty - this can happen
         * if we get a new packet before dequeue notices qlen==0.
         * Just update deadline.
         */
        uint64_t cur_time = hfsc_get_time();
        if (hfsc_has_rsc(cl)) {
            hfsc_rtsc_min(&cl->cl_rsc, &cl->rsc, cur_time,
                          cl->cumul, sched->tsc_hz);
            cl->cl_eligible = cl->cl_rsc;
            if (cl->rsc.m1 <= cl->rsc.m2) {
                cl->cl_eligible.dx = 0;
                cl->cl_eligible.dy = 0;
            }
            cl->cl_e = hfsc_sc_y2x(&cl->cl_eligible, cl->cumul);
            cl->cl_d = hfsc_sc_y2x(&cl->cl_rsc, cl->cumul + pkt_len);
            if (cl->rt_index < 0)
                hfsc_rt_heap_insert(sched, cl);
            else
                hfsc_rt_heap_update(sched, cl);
        }
    }

    return 0;
}

/*
 * hfsc_dequeue: Select and dequeue next packet.
 *
 * FIX #2: Deactivation is handled entirely through update_vf's
 * go_passive mechanism when qlen reaches 0. No separate
 * deactivate_class function.
 *
 * FIX #4: cumul is updated for RT path only, BEFORE updating
 * RT curves (so the next deadline uses the new cumul).
 */
struct rte_mbuf *hfsc_dequeue(hfsc_scheduler_t *sched)
{
    hfsc_class_t *cl;
    struct rte_mbuf *m = NULL;
    uint64_t cur_time = hfsc_get_time();
    bool is_realtime = false;

    if (!sched->root || sched->root->state != HFSC_CLASS_ACTIVE)
        return NULL;

    /* Try RT criterion first */
    cl = hfsc_select_rt(sched, cur_time);
    if (cl) {
        is_realtime = true;
    } else {
        /* Fall back to LS criterion */
        cl = hfsc_select_ls(sched, cur_time);
        if (!cl)
            return NULL;
    }

    /* Dequeue packet from selected leaf */
    if (rte_ring_dequeue(cl->queue, (void **)&m) != 0) {
        HFSC_LOG(WARNING, "Selected class %u has no packets!\n", cl->class_id);
        return NULL;
    }

    uint32_t pkt_len = rte_pktmbuf_pkt_len(m);

    cl->qlen--;
    cl->qbytes -= pkt_len;
    cl->stats_packets++;
    cl->stats_bytes += pkt_len;
    sched->total_packets_out++;

    /*
     * Update cumul BEFORE update_vf for RT criterion.
     * For LS criterion, do NOT update cumul (non-punishment).
     */
    if (is_realtime)
        cl->cumul += pkt_len;

    /*
     * Update virtual time hierarchy.
     * This increments total for each ancestor and may trigger
     * go_passive if qlen == 0.
     */
    hfsc_update_vf(sched, cl, pkt_len, cur_time);

    /*
     * Post-dequeue: update RT state.
     */
    if (hfsc_has_rsc(cl)) {
        if (cl->qlen > 0) {
            /* Peek next packet for deadline computation */
            struct rte_mbuf *next;
            if (rte_ring_peek(cl->queue, (void **)&next) == 0) {
                uint32_t next_len = rte_pktmbuf_pkt_len(next);
                if (is_realtime)
                    hfsc_update_ed(sched, cl, next_len);
                else
                    hfsc_update_d(sched, cl, next_len);
            }
        } else {
            /* Queue empty - remove from RT heap.
             * update_vf already handled go_passive for LS.
             */
            hfsc_rt_heap_remove(sched, cl);
        }
    }
    /* For classes without RSC: update_vf already handled deactivation
     * via go_passive when qlen==0 */

    return m;
}

bool hfsc_has_packets(hfsc_scheduler_t *sched)
{
    if (!sched->root)
        return false;

    for (uint32_t i = 0; i < sched->num_classes; i++) {
        if (sched->classes[i]->is_leaf && sched->classes[i]->qlen > 0)
            return true;
    }
    return false;
}

void hfsc_get_class_stats(hfsc_class_t *cl,
                          uint64_t *packets,
                          uint64_t *bytes,
                          uint64_t *drops)
{
    if (packets) *packets = cl->stats_packets;
    if (bytes)   *bytes   = cl->stats_bytes;
    if (drops)   *drops   = cl->stats_drops;
}

void hfsc_dump_state(hfsc_scheduler_t *sched)
{
    HFSC_LOG(INFO, "\n=== HFSC Scheduler State (v3.0) ===\n");
    HFSC_LOG(INFO, "Total classes: %u, RT heap: %u\n",
             sched->num_classes, sched->rt_heap_size);
    HFSC_LOG(INFO, "Packets: in=%lu out=%lu dropped=%lu\n",
             sched->total_packets_in, sched->total_packets_out,
             sched->total_drops);

    for (uint32_t i = 0; i < sched->num_classes; i++) {
        hfsc_class_t *cl = sched->classes[i];
        HFSC_LOG(INFO,
            "  Class %3u: %s qlen=%-4u leaf=%d nactive=%u "
            "vt=%lu vtoff=%lu total=%lu cumul=%lu "
            "pkts=%lu bytes=%lu drops=%lu\n",
            cl->class_id,
            cl->state == HFSC_CLASS_ACTIVE ? "ACT" : "INA",
            cl->qlen, cl->is_leaf, cl->cl_nactive,
            cl->cl_vt, cl->cl_vtoff, cl->total, cl->cumul,
            cl->stats_packets, cl->stats_bytes, cl->stats_drops);
    }
}

void hfsc_dump_vt_state(hfsc_scheduler_t *sched)
{
    HFSC_LOG(INFO, "\n=== Virtual Time State ===\n");
    for (uint32_t i = 0; i < sched->num_classes; i++) {
        hfsc_class_t *cl = sched->classes[i];
        HFSC_LOG(INFO,
            "  Class %3u: vt=%lu vtoff=%lu cvtmin=%lu cvtoff=%lu "
            "myf=%lu cl_f=%lu cfmin=%lu in_vt=%d period=%u/%u\n",
            cl->class_id,
            cl->cl_vt, cl->cl_vtoff,
            cl->cl_cvtmin, cl->cl_cvtoff,
            cl->cl_myf, cl->cl_f, cl->cl_cfmin,
            cl->in_vttree,
            cl->cl_vtperiod, cl->cl_parentperiod);
    }
}
/********************************************************************
 * HFSC Scheduler - Production-Ready Implementation v2.0 (LINUX-ALIGNED)
 * Based on Linux kernel net/sched/sch_hfsc.c (kernel 6.x)
 * 
 * ALL CRITICAL BUGS FIXED:
 *   - RT eligibility: scans all eligible classes (no early break)
 *   - cl_myf/cfmin: properly separated (never overwritten)
 *   - Activation: parents auto-activated, initialize first then activate
 *   - Parent passivity: excludes self from active count (cl_nactive)
 *   - Division by zero: properly handled in all cases
 *   - cvtmin reset: reset in all necessary places
 *   - Loop variable confusion: fixed in init_vf and update_vf
 *   - Double initialization: each class initialized exactly once
 *   - cl_f: propagated fit-time used correctly in selection
 ********************************************************************/

#ifndef HFSC_SCHEDULER_H
#define HFSC_SCHEDULER_H

#include <stdint.h>
#include <stdbool.h>
#include <rte_mbuf.h>
#include <rte_ring.h>
#include <rte_cycles.h>

/* ==================== CONFIGURATION ==================== */

#define HFSC_MAX_CLASSES        256
#define HFSC_MAX_CHILDREN       32
#define HFSC_QUEUE_SIZE         8192
#define HFSC_MAX_DEPTH          8

/* Precision for fixed-point arithmetic */
#define HFSC_SM_SHIFT           24
#define HFSC_SM_MASK            ((1ULL << HFSC_SM_SHIFT) - 1)

/* ==================== SERVICE CURVE ==================== */

typedef struct {
    uint64_t m1;    /* Initial slope (bytes/sec) */
    uint64_t d;     /* Delay for first segment (microseconds) */
    uint64_t m2;    /* Sustained slope (bytes/sec) */
} hfsc_service_curve_t;

typedef struct {
    uint64_t x;     /* Start time (TSC cycles) */
    uint64_t y;     /* Start bytes */
    uint64_t dx;    /* Duration of first segment (cycles) */
    uint64_t dy;    /* Bytes in first segment */
    uint64_t sm1;   /* Slope 1 (bytes/cycle, fixed-point) */
    uint64_t sm2;   /* Slope 2 (bytes/cycle, fixed-point) */
} hfsc_internal_sc_t;

/* ==================== CLASS STRUCTURE ==================== */

typedef enum {
    HFSC_CLASS_INACTIVE = 0,
    HFSC_CLASS_ACTIVE,
} hfsc_class_state_t;

typedef struct hfsc_class hfsc_class_t;

struct hfsc_class {
    /* Hierarchy */
    hfsc_class_t    *parent;
    hfsc_class_t    *children[HFSC_MAX_CHILDREN];
    uint32_t        num_children;
    uint32_t        class_id;
    bool            is_leaf;
    
    /* Queue (leaf classes only) */
    struct rte_ring *queue;
    uint32_t        qlen;           /* Queue length in packets */
    uint64_t        qbytes;         /* Queue length in bytes */
    
    /* Service curves */
    hfsc_service_curve_t rsc;       /* Real-time service curve */
    hfsc_service_curve_t fsc;       /* Fair service curve */
    hfsc_service_curve_t usc;       /* Upper-limit service curve */
    
    /* Runtime curves */
    hfsc_internal_sc_t cl_rsc;
    hfsc_internal_sc_t cl_fsc;
    hfsc_internal_sc_t cl_usc;
    hfsc_internal_sc_t cl_eligible;
    
    /* Accounting */
    uint64_t        cumul;
    uint64_t        total;
    uint64_t        last_update;
    
    /* Real-time criterion */
    uint64_t        cl_e;
    uint64_t        cl_d;
    int             rt_index;
    
    /* Link-sharing criterion */
    uint64_t        cl_vt;
    uint64_t        cl_vtoff;
    uint32_t        cl_vtperiod;
    uint32_t        cl_parentperiod;
    
    /* USC enforcement and fit-time tracking */
    uint64_t        cl_myf;         /* My fit-time from USC */
    uint64_t        cl_f;           /* Propagated fit-time: max(cl_myf, cl_cfmin) */
    uint64_t        cl_cfmin;       /* Min fit-time among active children */
    uint64_t        cl_cvtmin;      /* Min virtual time among active children */
    uint64_t        cl_cvtmax;      /* Max virtual time among active children */
    uint64_t        cl_cvtoff;      /* Max VT seen (for first child of new period) */
    
    /* Active children tracking */
    uint32_t        cl_nactive;     /* Number of active children */
    
    /* State */
    hfsc_class_state_t state;
    bool            in_vttree;      /* Flag only - no actual tree */
    
    /* Statistics */
    uint64_t        stats_packets;
    uint64_t        stats_bytes;
    uint64_t        stats_drops;
};

/* ==================== SCHEDULER STATE ==================== */

typedef struct {
    hfsc_class_t    *root;
    hfsc_class_t    *classes[HFSC_MAX_CLASSES];
    uint32_t        num_classes;
    
    /* Real-time heap (min-heap by deadline) */
    hfsc_class_t    **rt_heap;
    uint32_t        rt_heap_size;
    uint32_t        rt_heap_capacity;
    
    /* TSC frequency */
    uint64_t        tsc_hz;
    
    /* Statistics */
    uint64_t        total_packets_in;
    uint64_t        total_packets_out;
    uint64_t        total_drops;
} hfsc_scheduler_t;

/* ==================== API FUNCTIONS ==================== */

int hfsc_init(hfsc_scheduler_t **sched);
void hfsc_cleanup(hfsc_scheduler_t *sched);
hfsc_class_t *hfsc_create_root(hfsc_scheduler_t *sched,
                               const hfsc_service_curve_t *rsc,
                               const hfsc_service_curve_t *fsc,
                               const hfsc_service_curve_t *usc);
hfsc_class_t *hfsc_create_class(hfsc_scheduler_t *sched,
                                hfsc_class_t *parent,
                                uint32_t class_id,
                                bool is_leaf,
                                const hfsc_service_curve_t *rsc,
                                const hfsc_service_curve_t *fsc,
                                const hfsc_service_curve_t *usc);
int hfsc_enqueue(hfsc_scheduler_t *sched, hfsc_class_t *cl, 
                 struct rte_mbuf *m);
struct rte_mbuf *hfsc_dequeue(hfsc_scheduler_t *sched);
bool hfsc_has_packets(hfsc_scheduler_t *sched);
void hfsc_get_class_stats(hfsc_class_t *cl, 
                          uint64_t *packets, 
                          uint64_t *bytes, 
                          uint64_t *drops);
void hfsc_dump_state(hfsc_scheduler_t *sched);
void hfsc_dump_vt_state(hfsc_scheduler_t *sched);

#endif /* HFSC_SCHEDULER_H */
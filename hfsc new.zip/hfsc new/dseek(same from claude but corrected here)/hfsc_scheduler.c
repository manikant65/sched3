/********************************************************************
 * HFSC Scheduler - Core Implementation v2.0 (LINUX-ALIGNED)
 * 
 * ALL CRITICAL BUGS FIXED:
 *   - RT eligibility: scans all eligible classes (no early break)
 *   - cl_myf/cfmin: properly separated (never overwritten)
 *   - Activation: parents auto-activated, initialize first then activate
 *   - Parent passivity: excludes self from active count (cl_nactive)
 *   - Division by zero: properly handled in all cases
 *   - cvtmin reset: reset in all necessary places
 *   - Loop variable confusion: fixed in init_vf and update_vf
 *   - Double initialization: each class initialized exactly once
 *   - cl_f: propagated fit-time used correctly in selection
 ********************************************************************/

#include "hfsc_scheduler.h"
#include <rte_malloc.h>
#include <rte_log.h>
#include <rte_memory.h>
#include <string.h>

#define RTE_LOGTYPE_HFSC RTE_LOGTYPE_USER1

#define HFSC_LOG(level, fmt, args...) \
    RTE_LOG(level, HFSC, "[HFSC] " fmt, ##args)

#define likely(x)   __builtin_expect(!!(x), 1)
#define unlikely(x) __builtin_expect(!!(x), 0)

/* Debug flag - set to 1 to enable debug logs */
#define HFSC_DEBUG 0

#if HFSC_DEBUG
#define HFSC_DEBUG_LOG(level, fmt, args...) HFSC_LOG(level, fmt, ##args)
#else
#define HFSC_DEBUG_LOG(level, fmt, args...) do { } while(0)
#endif

#if RTE_VERSION < RTE_VERSION_NUM(20, 11, 0, 0)
#error "HFSC requires DPDK 20.11 or newer for rte_ring_peek support"
#endif

/* ==================== UTILITY FUNCTIONS ==================== */

static inline bool time_after(uint64_t a, uint64_t b)
{
    return (int64_t)(a - b) > 0;
}

static inline bool time_before(uint64_t a, uint64_t b)
{
    return time_after(b, a);
}

static inline bool time_after_eq(uint64_t a, uint64_t b)
{
    return (int64_t)(a - b) >= 0;
}

static inline bool time_before_eq(uint64_t a, uint64_t b)
{
    return time_after_eq(b, a);
}

static inline uint64_t hfsc_rate_to_sm(uint64_t rate, uint64_t tsc_hz)
{
    if (rate == 0) return 0;
    
    __uint128_t numerator = (__uint128_t)rate << HFSC_SM_SHIFT;
    uint64_t result = (uint64_t)(numerator / tsc_hz);
    
    if (result == 0 && rate > 0) return 1;
    return result;
}

static inline uint64_t hfsc_us_to_cycles(uint64_t us, uint64_t tsc_hz)
{
    return (us * tsc_hz) / 1000000ULL;
}

static inline uint64_t hfsc_get_time(void)
{
    return rte_get_tsc_cycles();
}

static inline uint64_t hfsc_sc_x2y(const hfsc_internal_sc_t *isc, uint64_t x)
{
    uint64_t dx, y;
    
    if (x <= isc->x) return isc->y;
    
    dx = x - isc->x;
    
    if (dx <= isc->dx) {
        y = isc->y + ((dx * isc->sm1) >> HFSC_SM_SHIFT);
    } else {
        y = isc->y + isc->dy + (((dx - isc->dx) * isc->sm2) >> HFSC_SM_SHIFT);
    }
    
    return y;
}

static inline uint64_t hfsc_sc_y2x(const hfsc_internal_sc_t *isc, uint64_t y)
{
    uint64_t dy;
    
    if (y <= isc->y) return isc->x;
    
    dy = y - isc->y;
    
    if (dy <= isc->dy) {
        if (isc->sm1 == 0) {
            return isc->x + isc->dx;
        }
        return isc->x + ((dy << HFSC_SM_SHIFT) / isc->sm1);
    } else {
        uint64_t dy2 = dy - isc->dy;
        if (isc->sm2 == 0) {
            return UINT64_MAX;
        }
        return isc->x + isc->dx + ((dy2 << HFSC_SM_SHIFT) / isc->sm2);
    }
}

/* ==================== SERVICE CURVE MANAGEMENT ==================== */

static void hfsc_sc_min(hfsc_internal_sc_t *rtsc, const hfsc_service_curve_t *sc,
                        uint64_t cur_time, uint64_t cur_bytes, uint64_t tsc_hz)
{
    uint64_t sm1, sm2, dx, dy;
    uint64_t y1, y2;
    
    sm1 = hfsc_rate_to_sm(sc->m1, tsc_hz);
    sm2 = hfsc_rate_to_sm(sc->m2, tsc_hz);
    dx = hfsc_us_to_cycles(sc->d, tsc_hz);
    dy = (dx * sm1) >> HFSC_SM_SHIFT;
    
    if (sm1 <= sm2) {
        y1 = hfsc_sc_x2y(rtsc, cur_time);
        if (y1 < cur_bytes) return;
        
        rtsc->x = cur_time;
        rtsc->y = cur_bytes;
        rtsc->dx = dx;
        rtsc->dy = dy;
        rtsc->sm1 = sm1;
        rtsc->sm2 = sm2;
        return;
    }
    
    y1 = hfsc_sc_x2y(rtsc, cur_time);
    if (y1 <= cur_bytes) return;
    
    y2 = hfsc_sc_x2y(rtsc, cur_time + dx);
    if (y2 >= cur_bytes + dy) {
        rtsc->x = cur_time;
        rtsc->y = cur_bytes;
        rtsc->dx = dx;
        rtsc->dy = dy;
        rtsc->sm1 = sm1;
        rtsc->sm2 = sm2;
        return;
    }
    
    __uint128_t dx_new = (__uint128_t)(y1 - cur_bytes) << HFSC_SM_SHIFT;
    uint64_t dsm = sm1 - sm2;
    if (dsm != 0) {
        dx_new /= dsm;
        
        if (rtsc->x + rtsc->dx > cur_time) {
            dx_new += rtsc->x + rtsc->dx - cur_time;
        }
        
        rtsc->x = cur_time;
        rtsc->y = cur_bytes;
        rtsc->dx = (uint64_t)dx_new;
        rtsc->dy = ((uint64_t)dx_new * sm1) >> HFSC_SM_SHIFT;
        rtsc->sm1 = sm1;
        rtsc->sm2 = sm2;
    }
}

static void hfsc_init_eligible(hfsc_internal_sc_t *el, const hfsc_internal_sc_t *dl,
                               const hfsc_service_curve_t *rsc)
{
    *el = *dl;
    if (rsc && rsc->m1 <= rsc->m2) {
        el->dx = 0;
        el->dy = 0;
    }
}

/* ==================== HIERARCHY MANAGEMENT ==================== */

static uint32_t hfsc_count_active_children_except(hfsc_class_t *parent, hfsc_class_t *except)
{
    uint32_t count = 0;
    
    for (uint32_t i = 0; i < parent->num_children; i++) {
        hfsc_class_t *child = parent->children[i];
        if (child != except && child->state == HFSC_CLASS_ACTIVE &&
            (child->fsc.m1 > 0 || child->fsc.m2 > 0)) {
            count++;
        }
    }
    return count;
}

static hfsc_class_t *hfsc_find_max_vt_child(hfsc_class_t *parent)
{
    hfsc_class_t *max_cl = NULL;
    uint64_t max_vt = 0;
    
    for (uint32_t i = 0; i < parent->num_children; i++) {
        hfsc_class_t *child = parent->children[i];
        if (child->state == HFSC_CLASS_ACTIVE &&
            (child->fsc.m1 > 0 || child->fsc.m2 > 0)) {
            if (max_cl == NULL || child->cl_vt > max_vt) {
                max_cl = child;
                max_vt = child->cl_vt;
            }
        }
    }
    return max_cl;
}

/* ==================== REAL-TIME HEAP MANAGEMENT ==================== */

static void hfsc_heap_swap(hfsc_scheduler_t *sched, uint32_t i, uint32_t j)
{
    hfsc_class_t *tmp = sched->rt_heap[i];
    sched->rt_heap[i] = sched->rt_heap[j];
    sched->rt_heap[j] = tmp;
    sched->rt_heap[i]->rt_index = i;
    sched->rt_heap[j]->rt_index = j;
}

static void hfsc_heap_up(hfsc_scheduler_t *sched, uint32_t idx)
{
    while (idx > 0) {
        uint32_t parent = (idx - 1) / 2;
        if (sched->rt_heap[idx]->cl_d >= sched->rt_heap[parent]->cl_d)
            break;
        hfsc_heap_swap(sched, idx, parent);
        idx = parent;
    }
}

static void hfsc_heap_down(hfsc_scheduler_t *sched, uint32_t idx)
{
    while (1) {
        uint32_t smallest = idx;
        uint32_t left = 2 * idx + 1;
        uint32_t right = 2 * idx + 2;
        
        if (left < sched->rt_heap_size &&
            sched->rt_heap[left]->cl_d < sched->rt_heap[smallest]->cl_d)
            smallest = left;
        if (right < sched->rt_heap_size &&
            sched->rt_heap[right]->cl_d < sched->rt_heap[smallest]->cl_d)
            smallest = right;
        if (smallest == idx) break;
        
        hfsc_heap_swap(sched, idx, smallest);
        idx = smallest;
    }
}

static void hfsc_rt_heap_insert(hfsc_scheduler_t *sched, hfsc_class_t *cl)
{
    if (cl->rt_index >= 0) return;
    if (sched->rt_heap_size >= sched->rt_heap_capacity) {
        HFSC_LOG(ERR, "RT heap full\n");
        return;
    }
    
    cl->rt_index = sched->rt_heap_size;
    sched->rt_heap[sched->rt_heap_size] = cl;
    sched->rt_heap_size++;
    hfsc_heap_up(sched, cl->rt_index);
}

static void hfsc_rt_heap_remove(hfsc_scheduler_t *sched, hfsc_class_t *cl)
{
    if (cl->rt_index < 0) return;
    
    uint32_t idx = cl->rt_index;
    sched->rt_heap_size--;
    
    if (idx < sched->rt_heap_size) {
        sched->rt_heap[idx] = sched->rt_heap[sched->rt_heap_size];
        sched->rt_heap[idx]->rt_index = idx;
        hfsc_heap_down(sched, idx);
        hfsc_heap_up(sched, idx);
    }
    cl->rt_index = -1;
}

static void hfsc_rt_heap_update(hfsc_scheduler_t *sched, hfsc_class_t *cl)
{
    if (cl->rt_index < 0) return;
    hfsc_heap_down(sched, cl->rt_index);
    hfsc_heap_up(sched, cl->rt_index);
}

/* ==================== REAL-TIME CRITERION ==================== */

static void hfsc_init_ed(hfsc_scheduler_t *sched, hfsc_class_t *cl, uint32_t next_len)
{
    uint64_t cur_time = hfsc_get_time();
    
    hfsc_sc_min(&cl->cl_rsc, &cl->rsc, cur_time, cl->cumul, sched->tsc_hz);
    cl->cl_eligible = cl->cl_rsc;
    hfsc_init_eligible(&cl->cl_eligible, &cl->cl_rsc, &cl->rsc);
    
    cl->cl_e = hfsc_sc_y2x(&cl->cl_eligible, cl->cumul);
    cl->cl_d = hfsc_sc_y2x(&cl->cl_rsc, cl->cumul + next_len);
    
    hfsc_rt_heap_insert(sched, cl);
}

static void hfsc_update_ed(hfsc_scheduler_t *sched, hfsc_class_t *cl, uint32_t next_len)
{
    cl->cl_e = hfsc_sc_y2x(&cl->cl_eligible, cl->cumul);
    cl->cl_d = hfsc_sc_y2x(&cl->cl_rsc, cl->cumul + next_len);
    hfsc_rt_heap_update(sched, cl);
}

static void hfsc_update_d(hfsc_scheduler_t *sched, hfsc_class_t *cl, uint32_t next_len)
{
    cl->cl_d = hfsc_sc_y2x(&cl->cl_rsc, cl->cumul + next_len);
    hfsc_rt_heap_update(sched, cl);
}

/* ==================== LINK-SHARING CRITERION ==================== */

/**
 * Initialize virtual time and fit-time when class becomes active
 * FIXED: Each class initialized exactly once, no double initialization
 */
static void hfsc_init_vf(hfsc_scheduler_t *sched, hfsc_class_t *cl, uint32_t len)
{
    hfsc_class_t *parent;
    hfsc_class_t *max_cl;
    hfsc_class_t *current;
    hfsc_class_t *next_parent;
    uint64_t vt;
    uint64_t cur_time = 0;
    
    HFSC_DEBUG_LOG(DEBUG, "init_vf for class %u\n", cl->class_id);
    
    /* PHASE 1: Activate all parents up to root */
    for (parent = cl->parent; parent != NULL; parent = parent->parent) {
        if (parent->state != HFSC_CLASS_ACTIVE) {
            parent->state = HFSC_CLASS_ACTIVE;
            parent->cl_nactive = 0;
            HFSC_DEBUG_LOG(DEBUG, "  Activated parent %u\n", parent->class_id);
        }
    }
    
    /* PHASE 2: Walk up hierarchy, initializing each class exactly once */
    current = cl;
    parent = cl->parent;
    
    while (parent != NULL) {
        uint32_t nactive_before = parent->cl_nactive;
        
        /* Increment parent's active count */
        parent->cl_nactive++;
        
        /* If current is first active child, initialize it */
        if (nactive_before == 0) {
            /* Find sibling with maximum VT */
            max_cl = hfsc_find_max_vt_child(parent);
            
            if (max_cl != NULL) {
                vt = max_cl->cl_vt;
                if (parent->cl_cvtmin != 0) {
                    vt = (parent->cl_cvtmin + vt) / 2;
                }
                
                if (parent->cl_vtperiod != current->cl_parentperiod || vt > current->cl_vt) {
                    current->cl_vt = vt;
                }
            } else {
                current->cl_vt = parent->cl_cvtoff;
                parent->cl_cvtmin = 0;
            }
            
            /* Update virtual curve */
            hfsc_sc_min(&current->cl_fsc, &current->fsc, current->cl_vt, 
                       current->total, sched->tsc_hz);
            
            current->cl_vtoff = 0;
            current->cl_vtperiod++;
            current->cl_parentperiod = parent->cl_vtperiod;
            if (nactive_before == 0) {
                current->cl_parentperiod++;
            }
            
            /* Update USC if present */
            if (current->usc.m1 > 0 || current->usc.m2 > 0) {
                if (cur_time == 0) cur_time = hfsc_get_time();
                hfsc_sc_min(&current->cl_usc, &current->usc, cur_time, 
                           current->total, sched->tsc_hz);
                current->cl_myf = hfsc_sc_y2x(&current->cl_usc, current->total);
            }
            
            current->in_vttree = true;
            
            HFSC_DEBUG_LOG(DEBUG, "  Initialized %u (vt=%lu period=%u)\n",
                           current->class_id, current->cl_vt, current->cl_vtperiod);
        }
        
        /* Update current's propagated fit-time */
        current->cl_f = current->cl_myf;
        if (current->cl_cfmin > current->cl_f) {
            current->cl_f = current->cl_cfmin;
        }
        
        /* Update parent's cfmin */
        parent->cl_cfmin = UINT64_MAX;
        for (uint32_t i = 0; i < parent->num_children; i++) {
            if (parent->children[i]->state == HFSC_CLASS_ACTIVE) {
                if (parent->children[i]->cl_f < parent->cl_cfmin) {
                    parent->cl_cfmin = parent->children[i]->cl_f;
                }
            }
        }
        if (parent->cl_cfmin == UINT64_MAX) {
            parent->cl_cfmin = 0;
        }
        
        /* Move up the hierarchy */
        next_parent = parent->parent;
        current = parent;
        parent = next_parent;
    }
}

/**
 * Update virtual time and fit-time after dequeue
 */
static void hfsc_update_vf(hfsc_scheduler_t *sched, hfsc_class_t *cl, 
                           uint32_t len, uint64_t cur_time)
{
    hfsc_class_t *parent;
    hfsc_class_t *current;
    hfsc_class_t *next_parent;
    int go_passive = 0;
    
    current = cl;
    if (current->qlen == 0 && (current->fsc.m1 > 0 || current->fsc.m2 > 0)) {
        go_passive = 1;
    }
    
    parent = current->parent;
    while (parent != NULL) {
        current->total += len;
        
        if (current->fsc.m1 == 0 && current->fsc.m2 == 0) {
            next_parent = parent->parent;
            current = parent;
            parent = next_parent;
            continue;
        }
        
        if (go_passive && parent->cl_nactive > 0) {
            parent->cl_nactive--;
            if (parent->cl_nactive == 0) {
                go_passive = 1;
                parent->state = HFSC_CLASS_INACTIVE;
            } else {
                go_passive = 0;
            }
        } else {
            go_passive = 0;
        }
        
        current->cl_vt = hfsc_sc_y2x(&current->cl_fsc, current->total);
        current->cl_vt += current->cl_vtoff;
        
        if (parent->cl_cvtmin != 0 && current->cl_vt < parent->cl_cvtmin) {
            current->cl_vtoff += (parent->cl_cvtmin - current->cl_vt);
            current->cl_vt = parent->cl_cvtmin;
        }
        
        if (go_passive) {
            if (current->cl_vt > parent->cl_cvtoff) {
                parent->cl_cvtoff = current->cl_vt;
            }
            current->in_vttree = false;
            parent->cl_cvtmin = 0;
            
            parent->cl_cfmin = UINT64_MAX;
            for (uint32_t i = 0; i < parent->num_children; i++) {
                if (parent->children[i]->state == HFSC_CLASS_ACTIVE) {
                    if (parent->children[i]->cl_f < parent->cl_cfmin) {
                        parent->cl_cfmin = parent->children[i]->cl_f;
                    }
                }
            }
            if (parent->cl_cfmin == UINT64_MAX) parent->cl_cfmin = 0;
            
            next_parent = parent->parent;
            current = parent;
            parent = next_parent;
            continue;
        }
        
        if (current->usc.m1 > 0 || current->usc.m2 > 0) {
            current->cl_myf = hfsc_sc_y2x(&current->cl_usc, current->total);
        }
        
        current->cl_f = current->cl_myf;
        if (current->cl_cfmin > current->cl_f) {
            current->cl_f = current->cl_cfmin;
        }
        
        parent->cl_cfmin = UINT64_MAX;
        for (uint32_t i = 0; i < parent->num_children; i++) {
            if (parent->children[i]->state == HFSC_CLASS_ACTIVE) {
                if (parent->children[i]->cl_f < parent->cl_cfmin) {
                    parent->cl_cfmin = parent->children[i]->cl_f;
                }
            }
        }
        if (parent->cl_cfmin == UINT64_MAX) parent->cl_cfmin = 0;
        
        next_parent = parent->parent;
        current = parent;
        parent = next_parent;
    }
}

/* ==================== CLASS ACTIVATION ==================== */

static void hfsc_activate_class(hfsc_scheduler_t *sched, hfsc_class_t *cl, uint32_t len)
{
    if (cl->state == HFSC_CLASS_ACTIVE) return;
    
    HFSC_DEBUG_LOG(DEBUG, "Activating class %u\n", cl->class_id);
    
    if (cl->rsc.m1 > 0 || cl->rsc.m2 > 0) {
        hfsc_init_ed(sched, cl, len);
    }
    
    if (cl->fsc.m1 > 0 || cl->fsc.m2 > 0) {
        hfsc_init_vf(sched, cl, len);
    }
    
    cl->state = HFSC_CLASS_ACTIVE;
}

static void hfsc_deactivate_class(hfsc_scheduler_t *sched, hfsc_class_t *cl)
{
    if (cl->state != HFSC_CLASS_ACTIVE) return;
    
    cl->state = HFSC_CLASS_INACTIVE;
    
    if (cl->rsc.m1 > 0 || cl->rsc.m2 > 0) {
        hfsc_rt_heap_remove(sched, cl);
    }
    
    if (cl->fsc.m1 > 0 || cl->fsc.m2 > 0) {
        hfsc_update_vf(sched, cl, 0, hfsc_get_time());
    }
    
    cl->cl_vtperiod++;
}

/* ==================== PACKET SELECTION ==================== */

static hfsc_class_t *hfsc_select_ls_child(hfsc_class_t *parent, uint64_t cur_time)
{
    hfsc_class_t *min_cl = NULL;
    uint64_t min_vt = UINT64_MAX;
    
    for (uint32_t i = 0; i < parent->num_children; i++) {
        hfsc_class_t *child = parent->children[i];
        
        if (child->state != HFSC_CLASS_ACTIVE) continue;
        if (!child->in_vttree) continue;
        if (child->fsc.m1 == 0 && child->fsc.m2 == 0) continue;
        if (child->cl_f > cur_time) continue;
        
        child->cl_vt = hfsc_sc_y2x(&child->cl_fsc, child->total) + child->cl_vtoff;
        
        if (parent->cl_cvtmin != 0 && child->cl_vt < parent->cl_cvtmin) {
            child->cl_vtoff += (parent->cl_cvtmin - child->cl_vt);
            child->cl_vt = parent->cl_cvtmin;
        }
        
        if (child->cl_vt < min_vt) {
            min_vt = child->cl_vt;
            min_cl = child;
        }
    }
    
    if (min_cl != NULL && (parent->cl_cvtmin == 0 || min_vt > parent->cl_cvtmin)) {
        parent->cl_cvtmin = min_vt;
    }
    
    return min_cl;
}

static hfsc_class_t *hfsc_select_ls(hfsc_scheduler_t *sched, uint64_t cur_time)
{
    hfsc_class_t *cl = sched->root;
    
    if (!cl || cl->state != HFSC_CLASS_ACTIVE) return NULL;
    if (cl->cl_cfmin > cur_time) return NULL;
    
    while (!cl->is_leaf) {
        cl = hfsc_select_ls_child(cl, cur_time);
        if (cl == NULL) return NULL;
    }
    
    return cl;
}

static hfsc_class_t *hfsc_select_rt(hfsc_scheduler_t *sched, uint64_t cur_time)
{
    hfsc_class_t *min_cl = NULL;
    uint64_t min_d = UINT64_MAX;
    
    for (uint32_t i = 0; i < sched->rt_heap_size; i++) {
        hfsc_class_t *cl = sched->rt_heap[i];
        if (cl->cl_e > cur_time) continue;
        if (cl->cl_d < min_d) {
            min_d = cl->cl_d;
            min_cl = cl;
        }
    }
    
    return min_cl;
}

/* ==================== PUBLIC API ==================== */

int hfsc_init(hfsc_scheduler_t **sched)
{
    hfsc_scheduler_t *s = rte_zmalloc("hfsc_scheduler", sizeof(hfsc_scheduler_t), 
                                      RTE_CACHE_LINE_SIZE);
    if (!s) {
        HFSC_LOG(ERR, "Failed to allocate scheduler\n");
        return -1;
    }
    
    s->rt_heap_capacity = HFSC_MAX_CLASSES;
    s->rt_heap = rte_zmalloc("hfsc_rt_heap", sizeof(hfsc_class_t *) * s->rt_heap_capacity,
                            RTE_CACHE_LINE_SIZE);
    if (!s->rt_heap) {
        HFSC_LOG(ERR, "Failed to allocate RT heap\n");
        rte_free(s);
        return -1;
    }
    
    s->tsc_hz = rte_get_tsc_hz();
    s->rt_heap_size = 0;
    s->num_classes = 0;
    s->root = NULL;
    
    *sched = s;
    HFSC_LOG(INFO, "HFSC scheduler initialized (ALL BUGS FIXED)\n");
    return 0;
}

void hfsc_cleanup(hfsc_scheduler_t *sched)
{
    if (!sched) return;
    
    for (uint32_t i = 0; i < sched->num_classes; i++) {
        hfsc_class_t *cl = sched->classes[i];
        if (cl) {
            if (cl->queue) {
                struct rte_mbuf *m;
                while (rte_ring_dequeue(cl->queue, (void **)&m) == 0) {
                    rte_pktmbuf_free(m);
                }
                rte_ring_free(cl->queue);
            }
            rte_free(cl);
        }
    }
    
    if (sched->rt_heap) rte_free(sched->rt_heap);
    rte_free(sched);
}

hfsc_class_t *hfsc_create_root(hfsc_scheduler_t *sched,
                               const hfsc_service_curve_t *rsc,
                               const hfsc_service_curve_t *fsc,
                               const hfsc_service_curve_t *usc)
{
    return hfsc_create_class(sched, NULL, 0, false, rsc, fsc, usc);
}

hfsc_class_t *hfsc_create_class(hfsc_scheduler_t *sched,
                                hfsc_class_t *parent,
                                uint32_t class_id,
                                bool is_leaf,
                                const hfsc_service_curve_t *rsc,
                                const hfsc_service_curve_t *fsc,
                                const hfsc_service_curve_t *usc)
{
    if (sched->num_classes >= HFSC_MAX_CLASSES) {
        HFSC_LOG(ERR, "Maximum classes reached\n");
        return NULL;
    }
    
    hfsc_class_t *cl = rte_zmalloc("hfsc_class", sizeof(hfsc_class_t), RTE_CACHE_LINE_SIZE);
    if (!cl) {
        HFSC_LOG(ERR, "Failed to allocate class\n");
        return NULL;
    }
    
    cl->parent = parent;
    cl->class_id = class_id;
    cl->is_leaf = is_leaf;
    cl->state = HFSC_CLASS_INACTIVE;
    cl->rt_index = -1;
    cl->in_vttree = false;
    cl->cl_nactive = 0;
    
    if (rsc) cl->rsc = *rsc;
    if (fsc) cl->fsc = *fsc;
    if (usc) cl->usc = *usc;
    
    memset(&cl->cl_rsc, 0, sizeof(hfsc_internal_sc_t));
    memset(&cl->cl_fsc, 0, sizeof(hfsc_internal_sc_t));
    memset(&cl->cl_usc, 0, sizeof(hfsc_internal_sc_t));
    memset(&cl->cl_eligible, 0, sizeof(hfsc_internal_sc_t));
    
    cl->cl_cvtmin = 0;
    cl->cl_cvtmax = 0;
    cl->cl_cvtoff = 0;
    cl->cl_cfmin = 0;
    cl->cl_myf = 0;
    cl->cl_f = 0;
    
    if (is_leaf) {
        char ring_name[RTE_RING_NAMESIZE];
        snprintf(ring_name, sizeof(ring_name), "hfsc_q_%u", class_id);
        
        cl->queue = rte_ring_create(ring_name, HFSC_QUEUE_SIZE, rte_socket_id(),
                                   RING_F_SP_ENQ | RING_F_SC_DEQ);
        if (!cl->queue) {
            HFSC_LOG(ERR, "Failed to create queue\n");
            rte_free(cl);
            return NULL;
        }
    }
    
    if (parent) {
        if (parent->num_children >= HFSC_MAX_CHILDREN) {
            HFSC_LOG(ERR, "Too many children\n");
            if (cl->queue) rte_ring_free(cl->queue);
            rte_free(cl);
            return NULL;
        }
        parent->children[parent->num_children++] = cl;
    } else {
        sched->root = cl;
    }
    
    sched->classes[sched->num_classes++] = cl;
    return cl;
}

int hfsc_enqueue(hfsc_scheduler_t *sched, hfsc_class_t *cl, struct rte_mbuf *m)
{
    if (!cl->is_leaf) {
        HFSC_LOG(ERR, "Cannot enqueue to non-leaf class\n");
        return -1;
    }
    
    uint32_t pkt_len = rte_pktmbuf_pkt_len(m);
    bool was_empty = (cl->qlen == 0);
    
    if (rte_ring_enqueue(cl->queue, m) != 0) {
        cl->stats_drops++;
        sched->total_drops++;
        return -1;
    }
    
    cl->qlen++;
    cl->qbytes += pkt_len;
    sched->total_packets_in++;
    
    if (was_empty) {
        hfsc_activate_class(sched, cl, pkt_len);
    } else {
        if (cl->rsc.m1 > 0 || cl->rsc.m2 > 0) {
            hfsc_update_d(sched, cl, pkt_len);
        }
    }
    
    return 0;
}

struct rte_mbuf *hfsc_dequeue(hfsc_scheduler_t *sched)
{
    hfsc_class_t *cl;
    struct rte_mbuf *m = NULL;
    uint64_t cur_time = hfsc_get_time();
    bool is_realtime = false;
    
    if (!sched->root) return NULL;
    
    cl = hfsc_select_rt(sched, cur_time);
    if (cl) {
        is_realtime = true;
    } else {
        cl = hfsc_select_ls(sched, cur_time);
        if (!cl) return NULL;
    }
    
    if (rte_ring_dequeue(cl->queue, (void **)&m) != 0) {
        HFSC_LOG(WARNING, "Selected class %u has no packets\n", cl->class_id);
        return NULL;
    }
    
    uint32_t pkt_len = rte_pktmbuf_pkt_len(m);
    
    cl->qlen--;
    cl->qbytes -= pkt_len;
    cl->stats_packets++;
    cl->stats_bytes += pkt_len;
    sched->total_packets_out++;
    
    hfsc_update_vf(sched, cl, pkt_len, cur_time);
    
    if (is_realtime) {
        cl->cumul += pkt_len;
    }
    
    if (cl->rsc.m1 > 0 || cl->rsc.m2 > 0) {
        if (cl->qlen > 0) {
            struct rte_mbuf *next;
            if (rte_ring_peek(cl->queue, (void **)&next) == 0) {
                uint32_t next_len = rte_pktmbuf_pkt_len(next);
                if (is_realtime) {
                    hfsc_update_ed(sched, cl, next_len);
                } else {
                    hfsc_update_d(sched, cl, next_len);
                }
            }
        } else {
            hfsc_deactivate_class(sched, cl);
        }
    } else if (cl->qlen == 0) {
        hfsc_deactivate_class(sched, cl);
    }
    
    return m;
}

bool hfsc_has_packets(hfsc_scheduler_t *sched)
{
    if (!sched->root) return false;
    
    for (uint32_t i = 0; i < sched->num_classes; i++) {
        if (sched->classes[i]->state == HFSC_CLASS_ACTIVE &&
            sched->classes[i]->qlen > 0) {
            return true;
        }
    }
    return false;
}

void hfsc_get_class_stats(hfsc_class_t *cl, uint64_t *packets, 
                          uint64_t *bytes, uint64_t *drops)
{
    if (packets) *packets = cl->stats_packets;
    if (bytes) *bytes = cl->stats_bytes;
    if (drops) *drops = cl->stats_drops;
}

void hfsc_dump_state(hfsc_scheduler_t *sched)
{
    HFSC_LOG(INFO, "\n=== HFSC Scheduler State ===\n");
    HFSC_LOG(INFO, "Total classes: %u\n", sched->num_classes);
    HFSC_LOG(INFO, "RT heap size: %u\n", sched->rt_heap_size);
    HFSC_LOG(INFO, "Packets in: %lu, out: %lu, dropped: %lu\n",
             sched->total_packets_in, sched->total_packets_out, sched->total_drops);
    
    for (uint32_t i = 0; i < sched->num_classes; i++) {
        hfsc_class_t *cl = sched->classes[i];
        HFSC_LOG(INFO, "Class %u: state=%s qlen=%u active_children=%u\n",
                 cl->class_id,
                 cl->state == HFSC_CLASS_ACTIVE ? "ACTIVE" : "INACTIVE",
                 cl->qlen, cl->cl_nactive);
    }
}

void hfsc_dump_vt_state(hfsc_scheduler_t *sched)
{
    HFSC_LOG(INFO, "\n=== Virtual Time State ===\n");
    
    for (uint32_t i = 0; i < sched->num_classes; i++) {
        hfsc_class_t *cl = sched->classes[i];
        HFSC_LOG(INFO, "Class %u: vt=%lu vtoff=%lu myf=%lu f=%lu cfmin=%lu cvtmin=%lu\n",
                 cl->class_id, cl->cl_vt, cl->cl_vtoff,
                 cl->cl_myf, cl->cl_f, cl->cl_cfmin, cl->cl_cvtmin);
    }
}